const coreTranslation = ['en_us'];

export default coreTranslation;
