import en_US from 'antd/es/locale/en_US';

const antdLocale = {
  en_us: en_US,
};

export default antdLocale;
